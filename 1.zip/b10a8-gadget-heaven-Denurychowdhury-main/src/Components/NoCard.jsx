
const NoCard = () => {
    return (
        <div>
            <h1>NO available data</h1>
        </div>
    );
};

export default NoCard;