# Gadgets heaven
## live link : https://gadgets-shop.surge.sh/
## pdf link 
[Download the PDF](https://drive.google.com/file/d/1kdJMefGKEHxxJFbzNeqdGWu-wc4WfK5f/view?usp=sharing)
##  Used React Fundamental concepts In this Project

* JSX (JavaScript XML)
* Components
* Props(properties)
* UseEffect()
* usestate
* State
* Hooks
* Context API
* Conditional rendering

## Handling and managing Data 
* Both Local Storage and Context api

## Major 9 key Features

* Dynamic Product Card 
* All Product card can be handled By category using left side category button
* In Each card view Details Button navigate to Product Details Page
* In product Details Card   show All details of a product 
* In details Card  two Button 'Add to cart ' and 'heart icon' 
* A user can add a product in his/her cart or wish list
* Each cart and Wish list have a Different page 
* in cart page ('Sort BY price') Bort sort items by price 
